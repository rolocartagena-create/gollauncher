package com.rolo.gollauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val screen = mutableStateOf(Screen.HOME)
    private val appsVersion = mutableIntStateOf(0)
    private lateinit var media: MediaRepo

    // Avisa cuando se instala o desinstala una app para refrescar la lista
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            appsVersion.intValue++
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La pantalla de un auto no debe apagarse sola
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        media = MediaRepo(applicationContext)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        setContent {
            LauncherTheme {
                LauncherApp(screen = screen, appsVersion = appsVersion.intValue, media = media)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Botón Home: siempre volver a la pantalla de inicio
        screen.value = Screen.HOME
    }

    override fun onResume() {
        super.onResume()
        media.start()
    }

    override fun onPause() {
        media.stop()
        super.onPause()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
