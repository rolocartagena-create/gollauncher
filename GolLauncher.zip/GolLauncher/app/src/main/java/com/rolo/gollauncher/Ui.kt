package com.rolo.gollauncher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen { HOME, APPS }
enum class PickTarget { NAV, PHONE, MUSIC, FAV }

private const val MAX_FAVS = 4
private const val KEY_HOME = "dest_home"
private const val KEY_WORK = "dest_work"

// ───────────────────────────── Raíz ─────────────────────────────

@Composable
fun LauncherApp(screen: MutableState<Screen>, appsVersion: Int, media: MediaRepo) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }

    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    LaunchedEffect(appsVersion) { apps = loadApps(ctx) }
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }

    val navApp = resolveSlot(prefs["slot_nav"], NAV_CANDIDATES, byPkg)
    val musicApp = resolveSlot(prefs["slot_music"], MUSIC_CANDIDATES, byPkg)
    val phoneApp = resolveSlot(prefs["slot_phone"], emptyList(), byPkg)
    val favApps = prefs.favorites.mapNotNull { byPkg[it] }

    var picker by remember { mutableStateOf<PickTarget?>(null) }
    var addrDialog by remember { mutableStateOf<String?>(null) }
    val mediaState by media.state.collectAsState()

    BackHandler(enabled = screen.value != Screen.HOME) { screen.value = Screen.HOME }

    val openNav: () -> Unit = {
        if (!ctx.launchApp(navApp?.pkg)) ctx.toast("Elige tu app de navegación: mantén pulsado el botón")
    }
    val openMusic: () -> Unit = {
        if (!ctx.launchApp(musicApp?.pkg)) ctx.toast("Elige tu app de música: mantén pulsado el botón")
    }
    val openPhone: () -> Unit = {
        if (phoneApp != null) ctx.launchApp(phoneApp.pkg) else ctx.openDialer()
    }
    val goDest: (String) -> Unit = { key ->
        val address = prefs[key]
        if (address.isNullOrBlank()) addrDialog = key else ctx.navigateTo(address, navApp?.pkg)
    }
    val addFav: (String) -> Unit = { pkg ->
        val cur = prefs.favorites
        when {
            pkg in cur -> ctx.toast("Ya está en favoritos")
            cur.size >= MAX_FAVS -> ctx.toast("Máximo $MAX_FAVS favoritos. Quita uno en Inicio (mantén pulsado)")
            else -> {
                prefs.favorites = cur + pkg
                ctx.toast("Añadida a favoritos")
            }
        }
    }

    Row(Modifier.fillMaxSize().background(Gol.bg)) {
        Rail(
            screen = screen.value,
            navApp = navApp,
            phoneApp = phoneApp,
            musicApp = musicApp,
            onNav = openNav,
            onNavLong = { picker = PickTarget.NAV },
            onPhone = openPhone,
            onPhoneLong = { picker = PickTarget.PHONE },
            onMusic = openMusic,
            onMusicLong = { picker = PickTarget.MUSIC },
            onHome = { screen.value = Screen.HOME },
            onApps = { screen.value = Screen.APPS },
        )
        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (screen.value) {
                Screen.HOME -> HomeContent(
                    navApp = navApp,
                    homeAddr = prefs[KEY_HOME],
                    workAddr = prefs[KEY_WORK],
                    media = mediaState,
                    favs = favApps,
                    onOpenNav = openNav,
                    onHome = { goDest(KEY_HOME) },
                    onHomeLong = { addrDialog = KEY_HOME },
                    onWork = { goDest(KEY_WORK) },
                    onWorkLong = { addrDialog = KEY_WORK },
                    onPrev = { media.previous() },
                    onPlay = { media.playPause() },
                    onNext = { media.next() },
                    onOpenPlayer = { ctx.launchApp(mediaState.pkg) },
                    onOpenMusic = openMusic,
                    onGrantAccess = { ctx.openNotificationAccessSettings() },
                    onOpenFav = { ctx.launchApp(it.pkg) },
                    onRemoveFav = { app ->
                        prefs.favorites = prefs.favorites - app.pkg
                        ctx.toast("${app.label} quitada de favoritos")
                    },
                    onAddFav = { picker = PickTarget.FAV },
                )
                Screen.APPS -> AppDrawer(
                    apps = apps,
                    onOpen = { ctx.launchApp(it.pkg) },
                    onFav = { addFav(it.pkg) },
                )
            }
        }
    }

    picker?.let { target ->
        AppPickerDialog(
            title = when (target) {
                PickTarget.NAV -> "App de navegación"
                PickTarget.PHONE -> "App de teléfono / Bluetooth"
                PickTarget.MUSIC -> "App de música"
                PickTarget.FAV -> "Añadir a favoritos"
            },
            apps = apps,
            showReset = target != PickTarget.FAV,
            onPick = { app ->
                when (target) {
                    PickTarget.NAV -> prefs["slot_nav"] = app?.pkg
                    PickTarget.PHONE -> prefs["slot_phone"] = app?.pkg
                    PickTarget.MUSIC -> prefs["slot_music"] = app?.pkg
                    PickTarget.FAV -> if (app != null) addFav(app.pkg)
                }
                picker = null
            },
            onDismiss = { picker = null },
        )
    }

    addrDialog?.let { key ->
        AddressDialog(
            title = if (key == KEY_HOME) "Dirección de Casa" else "Dirección de Trabajo",
            initial = prefs[key] ?: "",
            onSave = {
                prefs[key] = it.ifBlank { null }
                addrDialog = null
            },
            onClear = {
                prefs[key] = null
                addrDialog = null
            },
            onDismiss = { addrDialog = null },
        )
    }
}

// ───────────────────────────── Barra lateral ─────────────────────────────

@Composable
private fun Rail(
    screen: Screen,
    navApp: AppInfo?,
    phoneApp: AppInfo?,
    musicApp: AppInfo?,
    onNav: () -> Unit,
    onNavLong: () -> Unit,
    onPhone: () -> Unit,
    onPhoneLong: () -> Unit,
    onMusic: () -> Unit,
    onMusicLong: () -> Unit,
    onHome: () -> Unit,
    onApps: () -> Unit,
) {
    Column(
        Modifier
            .width(92.dp)
            .fillMaxHeight()
            .background(Gol.surface)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            RailSlot(onClick = onNav, onLong = onNavLong) { RailIcon(navApp, Icons.Rounded.Navigation, "Navegación") }
            RailSlot(onClick = onPhone, onLong = onPhoneLong) { RailIcon(phoneApp, Icons.Rounded.Phone, "Teléfono") }
            RailSlot(onClick = onMusic, onLong = onMusicLong) { RailIcon(musicApp, Icons.Rounded.MusicNote, "Música") }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            RailSlot(selected = screen == Screen.HOME, onClick = onHome) {
                Icon(Icons.Rounded.Home, "Inicio", tint = if (screen == Screen.HOME) Gol.accent else Gol.text, modifier = Modifier.size(32.dp))
            }
            RailSlot(selected = screen == Screen.APPS, onClick = onApps) {
                Icon(Icons.Rounded.Apps, "Todas las apps", tint = if (screen == Screen.APPS) Gol.accent else Gol.text, modifier = Modifier.size(32.dp))
            }
            ClockBlock()
        }
    }
}

@Composable
private fun RailIcon(app: AppInfo?, fallback: ImageVector, desc: String) {
    if (app != null) {
        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(46.dp))
    } else {
        Icon(fallback, desc, tint = Gol.text, modifier = Modifier.size(32.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RailSlot(
    selected: Boolean = false,
    onClick: () -> Unit,
    onLong: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(if (selected) Gol.accent.copy(alpha = 0.18f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
private fun ClockBlock() {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - (now % 60_000L) + 50L)
        }
    }
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(ctx) }
    val timeFmt = remember { SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEE d MMM", Locale.getDefault()) }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 4.dp)) {
        Text(timeFmt.format(Date(now)), color = Gol.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text(dateFmt.format(Date(now)), color = Gol.dim, fontSize = 12.sp)
    }
}

// ───────────────────────────── Inicio ─────────────────────────────

@Composable
private fun HomeContent(
    navApp: AppInfo?,
    homeAddr: String?,
    workAddr: String?,
    media: MediaUi,
    favs: List<AppInfo>,
    onOpenNav: () -> Unit,
    onHome: () -> Unit,
    onHomeLong: () -> Unit,
    onWork: () -> Unit,
    onWorkLong: () -> Unit,
    onPrev: () -> Unit,
    onPlay: () -> Unit,
    onNext: () -> Unit,
    onOpenPlayer: () -> Unit,
    onOpenMusic: () -> Unit,
    onGrantAccess: () -> Unit,
    onOpenFav: (AppInfo) -> Unit,
    onRemoveFav: (AppInfo) -> Unit,
    onAddFav: () -> Unit,
) {
    Row(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        NavCard(
            modifier = Modifier.weight(1.25f).fillMaxHeight(),
            navApp = navApp,
            homeAddr = homeAddr,
            workAddr = workAddr,
            onOpen = onOpenNav,
            onHome = onHome,
            onHomeLong = onHomeLong,
            onWork = onWork,
            onWorkLong = onWorkLong,
        )
        Column(
            Modifier.weight(1f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            MediaCard(
                modifier = Modifier.weight(1.3f).fillMaxWidth(),
                m = media,
                onPrev = onPrev,
                onPlay = onPlay,
                onNext = onNext,
                onOpenPlayer = onOpenPlayer,
                onOpenMusic = onOpenMusic,
                onGrantAccess = onGrantAccess,
            )
            FavCard(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                favs = favs,
                onOpen = onOpenFav,
                onRemove = onRemoveFav,
                onAdd = onAddFav,
            )
        }
    }
}

// ───────────── Tarjeta de navegación ─────────────

@Composable
private fun NavCard(
    modifier: Modifier,
    navApp: AppInfo?,
    homeAddr: String?,
    workAddr: String?,
    onOpen: () -> Unit,
    onHome: () -> Unit,
    onHomeLong: () -> Unit,
    onWork: () -> Unit,
    onWorkLong: () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Gol.surface)
            .clickable(onClick = onOpen),
    ) {
        MapBackdrop(Modifier.fillMaxSize())
        Text(
            navApp?.label ?: "Elige tu app de navegación",
            color = Gol.dim,
            fontSize = 14.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(24.dp),
        )
        Column(Modifier.align(Alignment.BottomStart).padding(24.dp)) {
            Text("¿A dónde vamos?", color = Gol.text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DestChip(Icons.Rounded.Home, "Casa", homeAddr, onHome, onHomeLong)
                DestChip(Icons.Rounded.Work, "Trabajo", workAddr, onWork, onWorkLong)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DestChip(icon: ImageVector, label: String, address: String?, onClick: () -> Unit, onLong: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Gol.surface2)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Gol.accent, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, color = Gol.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Text(
                address ?: "Toca para configurar",
                color = Gol.dim,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(120.dp),
            )
        }
    }
}

/** Mapa estilizado (decorativo): calles, una ruta y la flecha de destino. */
@Composable
private fun MapBackdrop(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF18212B), Color(0xFF10161D))))

        val road = Color(0xFF232D39)
        val step = 90.dp.toPx()
        var x = step * 0.4f
        while (x < w + h) {
            drawLine(road, Offset(x, 0f), Offset(x - h * 0.25f, h), strokeWidth = 14.dp.toPx())
            x += step
        }
        var y = step * 0.5f
        while (y < h) {
            drawLine(road, Offset(0f, y), Offset(w, y + 40.dp.toPx()), strokeWidth = 10.dp.toPx())
            y += step
        }

        val route = Path().apply {
            moveTo(w * 0.15f, h * 0.95f)
            cubicTo(w * 0.30f, h * 0.60f, w * 0.55f, h * 0.75f, w * 0.60f, h * 0.35f)
            lineTo(w * 0.80f, h * 0.14f)
        }
        drawPath(route, Gol.accent, style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Gol.accent, 16.dp.toPx(), Offset(w * 0.80f, h * 0.14f))
        drawCircle(Color.White, 6.dp.toPx(), Offset(w * 0.80f, h * 0.14f))

        // Degradado abajo para que el texto se lea bien
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, Color(0xDD0A0D12)),
                startY = h * 0.35f,
                endY = h,
            )
        )
    }
}

// ───────────── Tarjeta de música ─────────────

@Composable
private fun MediaCard(
    modifier: Modifier,
    m: MediaUi,
    onPrev: () -> Unit,
    onPlay: () -> Unit,
    onNext: () -> Unit,
    onOpenPlayer: () -> Unit,
    onOpenMusic: () -> Unit,
    onGrantAccess: () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Gol.surface)
            .clickable(enabled = m.pkg != null, onClick = onOpenPlayer)
            .padding(20.dp),
    ) {
        when {
            !m.hasAccess -> EmptyState(
                Icons.Rounded.MusicNote,
                "Activa el acceso a notificaciones para ver qué suena",
                "Dar acceso",
                onGrantAccess,
            )
            m.title == null -> EmptyState(Icons.Rounded.MusicNote, "Nada sonando", "Abrir música", onOpenMusic)
            else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val art = remember(m.art) { m.art?.asImageBitmap() }
                    if (art != null) {
                        Image(
                            bitmap = art,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(92.dp).clip(RoundedCornerShape(16.dp)),
                        )
                    } else {
                        Box(
                            Modifier.size(92.dp).clip(RoundedCornerShape(16.dp)).background(Gol.surface2),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.MusicNote, null, tint = Gol.dim, modifier = Modifier.size(40.dp))
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            m.title ?: "",
                            color = Gol.text,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            m.artist ?: "",
                            color = Gol.dim,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CtrlButton(Icons.Rounded.SkipPrevious, "Anterior", onPrev)
                    Box(
                        Modifier.size(76.dp).clip(CircleShape).background(Gol.accent).clickable(onClick = onPlay),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            if (m.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            if (m.playing) "Pausa" else "Reproducir",
                            tint = Gol.bg,
                            modifier = Modifier.size(44.dp),
                        )
                    }
                    CtrlButton(Icons.Rounded.SkipNext, "Siguiente", onNext)
                }
            }
        }
    }
}

@Composable
private fun CtrlButton(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(68.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = Gol.text, modifier = Modifier.size(40.dp))
    }
}

@Composable
private fun EmptyState(icon: ImageVector, text: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = Gol.dim, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(8.dp))
        Text(text, color = Gol.dim, fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = Gol.accent, contentColor = Gol.bg),
        ) { Text(button) }
    }
}

// ───────────── Favoritos ─────────────

@Composable
private fun FavCard(
    modifier: Modifier,
    favs: List<AppInfo>,
    onOpen: (AppInfo) -> Unit,
    onRemove: (AppInfo) -> Unit,
    onAdd: () -> Unit,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(28.dp))
            .background(Gol.surface)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        favs.take(MAX_FAVS).forEach { app ->
            AppTile(app, Modifier.weight(1f), onClick = { onOpen(app) }, onLong = { onRemove(app) })
        }
        if (favs.size < MAX_FAVS) {
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).clickable(onClick = onAdd).padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(Gol.surface2),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Add, "Añadir favorito", tint = Gol.accent, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text("Añadir", color = Gol.dim, fontSize = 14.sp, maxLines = 1)
            }
        }
    }
}

// ───────────── Cajón de apps ─────────────

@Composable
private fun AppDrawer(apps: List<AppInfo>, onOpen: (AppInfo) -> Unit, onFav: (AppInfo) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Text(
            "Todas las apps · mantén pulsado para añadir a favoritos",
            color = Gol.dim,
            fontSize = 14.sp,
            modifier = Modifier.padding(vertical = 16.dp),
        )
        LazyVerticalGrid(
            columns = GridCells.Adaptive(120.dp),
            contentPadding = PaddingValues(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(apps, key = { it.pkg }) { app ->
                AppTile(app, onClick = { onOpen(app) }, onLong = { onFav(app) })
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppTile(
    app: AppInfo,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLong: (() -> Unit)? = null,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            app.label,
            color = Gol.text,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

// ───────────── Diálogos ─────────────

@Composable
private fun AppPickerDialog(
    title: String,
    apps: List<AppInfo>,
    showReset: Boolean,
    onPick: (AppInfo?) -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Gol.surface2,
            modifier = Modifier.fillMaxWidth(0.8f).fillMaxHeight(0.85f),
        ) {
            Column(Modifier.padding(20.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        title,
                        color = Gol.text,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f),
                    )
                    if (showReset) TextButton(onClick = { onPick(null) }) { Text("Automático") }
                    TextButton(onClick = onDismiss) { Text("Cerrar") }
                }
                LazyVerticalGrid(columns = GridCells.Adaptive(110.dp), modifier = Modifier.fillMaxSize()) {
                    items(apps, key = { it.pkg }) { app ->
                        AppTile(app, onClick = { onPick(app) })
                    }
                }
            }
        }
    }
}

@Composable
private fun AddressDialog(
    title: String,
    initial: String,
    onSave: (String) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Gol.surface2,
        title = { Text(title, color = Gol.text) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Dirección o lugar") },
            )
        },
        confirmButton = { TextButton(onClick = { onSave(text.trim()) }) { Text("Guardar") } },
        dismissButton = {
            Row {
                if (initial.isNotEmpty()) TextButton(onClick = onClear) { Text("Borrar") }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        },
    )
}
