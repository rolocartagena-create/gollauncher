package com.rolo.gollauncher

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf

/**
 * Preferencias guardadas en el teléfono, pero observables por Compose
 * (si cambian, la pantalla se redibuja sola).
 */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gol_launcher", Context.MODE_PRIVATE)
    private val map = mutableStateMapOf<String, String>().apply {
        sp.all.forEach { (k, v) -> if (v is String) put(k, v) }
    }

    operator fun get(key: String): String? = map[key]

    operator fun set(key: String, value: String?) {
        if (value == null) {
            map.remove(key)
            sp.edit().remove(key).apply()
        } else {
            map[key] = value
            sp.edit().putString(key, value).apply()
        }
    }

    /** Paquetes de las apps favoritas (máximo 4). */
    var favorites: List<String>
        get() = (map["favs"] ?: "").split(",").filter { it.isNotBlank() }
        set(v) {
            this["favs"] = if (v.isEmpty()) null else v.joinToString(",")
        }
}
